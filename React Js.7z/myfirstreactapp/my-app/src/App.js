import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
// import Button from './button/btn';
// import Result from './button/result';

import Cardlistcomponent from './cards/cardList';
import AddCardcomponent from './cards/addCard';

import { Grid, Row, Col, Nav, NavItem } from '../node_modules/react-bootstrap';
import ToggleDisplay from 'react-toggle-display';
import Example from './modal/Example';
import {
  HelpBlock,
  FormGroup,
  FormControl,
  ControlLabel,
  Modal,
  Button
} from "react-bootstrap";
class App extends Component {
  state = {
    show:false,
    counter: 0,
    currentCardObj: { name: 'Test', age: 0,email: '' },
     studentList: [{
      name: 'pinaki3rf',
      age: 24,
      email: 'pinaki.best@gmail.com'
    }, {
      name: 'pinaki2sfdsdgfvsd',
      age: 23,
      email: 'pinaki1.best@gmail.com'
    }],
  };
  incrementCounter = (value) => {
    this.setState((prevState) => {
      return {
        counter: prevState.counter + value
      }
    })
  };
  showModal=()=>{
    this.setState((prevState) => {
      return {
         show:true
      }
  })
  }
  reset=()=>{
    this.setState((prevState) => {
      return {
         show:false
      }
  })
  }
  AddToList = (value) => {
    this.setState((prevState) => {
      return {
        studentList: prevState.studentList.concat(value)
      }
    })
  };
  getCurrentCardObj=(value)=>{
    this.setState((prevState) => {
      return {
       currentCardObj:value
      }
  })
 this.showModal();
  }
 render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <Button bsStyle="primary" onClick={this.showModal} >Add New card</Button>
       {/* {<Button incrememtValue={1} onClickFunction={this.incrementCounter} />}
        {<Result counter={this.state.counter} />}
        {<Button incrememtValue={5} onClickFunction={this.incrementCounter} />} */}
       {<Cardlistcomponent cards={this.state.studentList} setCurrentCardObj={this.getCurrentCardObj} />}
        <ToggleDisplay if={this.state.show} tag="section">
          {<AddCardcomponent isToShow={this.state.show} existingCardDetails={this.state.currentCardObj} onClickClose={this.reset} onAddtoList={this.AddToList} />}
        </ToggleDisplay>
     </div>
    );
  }
}
export default App;
