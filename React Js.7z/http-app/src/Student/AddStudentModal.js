import React, { Component } from 'react';
import { HelpBlock, FormGroup, FormControl, ControlLabel, Modal, Button, Form, Col,Row, Checkbox } 
          from "react-bootstrap";

class AddStudentModalcomponent extends Component {
    constructor(props, context) {
        super(props, context);
        this.handleShow = this.handleShow.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }
    state = {
        newStudent:{ id: '', name: '', age: '' } 
    };
    AddOrUpdateStudent(data) {
        this.setState({  newStudent:data });
      }
    handleClose() {
    this.props.reset();
    }
    handleShow() {
        this.props.isToShow=false;
        this.setState({  newStudent:{} });
    }
    AddStudent(event){
        event.preventDefault();
       
        this.props.updateStudenrDetails(this.state.newStudent);
      this.handleClose();
    }
    handleChange = (propertyName, event) => {
        const obj = this.state.newStudent;
        obj[propertyName] = event.target.value;
        this.setState({ newStudent: obj });
    }

    render() {
        return (
            <div>
                <Modal show={this.props.isToShow} onHide={this.handleClose}>
                    <Modal.Header closeButton>
                        <Modal.Title>Modal heading</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <Form horizontal onSubmit={this.AddStudent.bind(this)} >
                            <FormGroup controlId="formHorizontalName">
                                <Col componentClass={ControlLabel} sm={1}>
                                    name
                            </Col>
                                <Col sm={10}>
                                    <FormControl type="text"
                                        onChange={this.handleChange.bind(this, 'name')}
                                        value={this.state.newStudent.name}
                                        placeholder="name" />
                                </Col>
                            </FormGroup>
                            <FormGroup controlId="formHorizontalAge">
                                <Col componentClass={ControlLabel} sm={2}>
                                    Age
                            </Col>
                                <Col sm={10}>
                                    <FormControl type="number"
                                        onChange={this.handleChange.bind(this, 'age')}
                                        value={this.state.newStudent.age}
                                        placeholder="age" />
                                </Col>
                            </FormGroup>
                          
                            <FormGroup>
                                <Col smOffset={2} sm={10}>
                                    <Button type="submit" >Add</Button>
                                </Col>
                            </FormGroup>
                        </Form>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={this.handleClose}>Close</Button>
                    </Modal.Footer>
                </Modal>
            </div>
        );
    }
}
export default AddStudentModalcomponent;