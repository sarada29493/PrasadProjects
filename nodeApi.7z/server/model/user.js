var mongoose = require("mongoose");
var ObjectId = require('mongodb').ObjectID;
var userSchema = mongoose.Schema({
    firstName: String,
    lastName: String,
    dOB: Date,
    contactNumber: Number
    
});
var user = mongoose.model('User', userSchema);

exports.getUserModelSchema = function (req, res) {
    return user;
};
