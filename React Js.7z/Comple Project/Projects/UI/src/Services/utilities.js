
export const utilityService = {
    getloginStats,
    setloginStats,
};

function setloginStats(value) {
    sessionStorage.setItem("loginStatus",value);
}
function getloginStats() {
   return sessionStorage.getItem("loginStatus");
}
export default {
    utilityService,
}