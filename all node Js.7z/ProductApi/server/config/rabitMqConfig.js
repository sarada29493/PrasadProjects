var amqp = require('amqplib/callback_api');
var conn;
var chn;
(async function() {
    if(!conn) {
        try {
            amqp.connect('amqp://localhost', function(error0, connection) {
                if (error0) {
                       console.log(error0);
                    }
                    conn=connection;
                    chn=  conn.createChannel();
             }); 
        } catch (error) {
            console.log("There was a problem with connection.\n" + error);
        }
    }
})();

exports.getChannel =  function () {
    return chn;
};
exports.getConection =  function () {
    return conn;
};
