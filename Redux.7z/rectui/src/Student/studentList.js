import React from 'react'
import { Table,Button } from 'reactstrap';
import io from 'socket.io-client';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
class StudentList extends React.Component {
    constructor(props,context)
    {
        super(props,context);
        
         this.socket = io('https://powerful-dawn-87203.herokuapp.com');
        this.state={
            StudentListTemp :[
              { id: 1, name: "Pinaki",age:10 }
            ],
            listItems:null,
            isloading:false,
            isToShow:false,
            isLogin:false,
            msgFromCheckout:"Test"
           }
           this.getStudentList = this.getStudentList.bind(this);
          
           this.Edit = this.Edit.bind(this);
           this.setData = this.setData.bind(this);
           
     
    }
    setData(msg)
  {
    this.setState({
      msgFromCheckout:  msg
      }
   );
  }
    componentDidMount() {
      this.socket.on('connect', function(){
        console.log("reajs connected.")

      });
      let self = this;
      this.socket.on('broadcast',function(data) {
        console.log(data);
        self.setData(data.description);
     });
        this.getStudentList();
        
    }
Edit(cell,i) {

    this.setState({
        StudentListTemp:  this.state.StudentListTemp.concat({ 'id': 3, 'name': "sara",'age':10 }) 
        }
        
      , function () {
        this.getStudentList();
    });
  
  
}


        getStudentList()
        {
           
            this.setState((prevState) => {
                return {
                 
                  name:"wqefr43",
                  listItems:this.state.StudentListTemp.map(function(item,i) {
                    return (
                      <tr key={i}>
                      <td>{item.name}</td>
                      <td>{item.age}</td>
                      <td>
                      <Button color="primary"  onClick = {()=>this.Edit(item,i)}
                                >Edit</Button>
                      </td>
                    
                      </tr>
                     
                    );
                  },this)
                 
                }

            });

        }

  render() {
    return <div>
           <p> {this.state.msgFromCheckout}</p>
      
            <Table>
            <thead>
              <tr>
            
                <th>Name</th>
                <th>Age</th>
                <th>Action</th>
               
              </tr>
            </thead>
            <tbody>
            {this.state.listItems}
            </tbody>
          </Table>
        
            </div>
  }
}
export default StudentList