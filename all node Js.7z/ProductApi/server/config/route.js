


var productController = require('../controller/ProductController');


module.exports = function (app, dir) {
    
   let routePath='/productApi'
    app.get(routePath, productController.test);
    app.get(routePath+'/getProductDetails', productController.getProductDetails);
    app.get(routePath+'/updateProductPrice', productController.updateProductPrice);
    
}
