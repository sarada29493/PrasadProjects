

export const HttpService = {
    get,
    post,
    logout
};
function GetURI()
{
    return "http://localhost:3031/loginApi/";
}
function setHeadrs(){
        return {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' +  sessionStorage.getItem("token")
        };
}
function post(url,data) {
    const requestOptions = {
        method: 'POST',
        headers: setHeadrs(),
        body: JSON.stringify(data)
    };

    return fetch(GetURI()+url, requestOptions)
        .then(handleResponse)
        .then(user => {
            // login successful if there's a user in the response
            
            return user;
        });
}


function get(url) {
    
    const requestOptions = {
        method: 'GET',
        headers: setHeadrs()
    };

    return fetch(GetURI()+url, requestOptions).then(handleResponse);
}
function logout() {
    // remove user from local storage to log user out
    sessionStorage.removeItem('token');
}
function handleResponse(response) {
   
    return response.text().then(text => {
        const data = text && JSON.parse(text);
        if (!response.ok) {
            if (response.status === 401) {
                // auto logout if 401 response returned from api
                 logout();
            }

            const error = (data && data.message) || response.status;
            return Promise.reject(error);
        }

        return data;
    });
}