import React from 'react'
import loading from '../images/loading.gif';
class Loading extends React.Component {
  render() {
    return <div>
     
       <div id="mydiv" > 
     <img className="ajax-loader" src={loading}  />
   </div>                   
     
    </div> 
   
  }
}
export default Loading;