﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace coreApi.Models
{
    public partial class pinakiDatabaseContext : DbContext
    {
        public virtual DbSet<StudentDemo> StudentDemos { get; set; }
    }
}
