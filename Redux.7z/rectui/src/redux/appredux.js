import {createStore, applyMiddleware} from 'redux';
import logger from 'redux-logger';
import thunk from 'redux-thunk';

var defaulState={
    originAmount:1,
    users:[{Id: "5b72bfa31001cf388cf60075",  Email: "Hyderabad12e3", Password: "1"}]
};
function amount(state=defaulState,action)
{
    if(action.type==="change_origin_amoult")
    {
        return Object.assign({},state,{originAmount:action.data });    
    }
    else if(action.type==="change_getUsers"){
        return Object.assign({},state,{users:action.data });    
    }
    else
    {
        return state;
    }  
}
var store=createStore(
    amount,
    applyMiddleware(thunk,logger)
);
export default store;


