import React from 'react'
import {HttpService} from '../Services/Http.Service';
import Loading from '../Loader/Loading';
import { Button ,Alert,Navbar,Nav,Form,FormControl} from 'react-bootstrap';
import {utilityService} from '../Services/utilities'


class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
       UserModel:{
        Username: '',
        Password: '',
       },
        submitted: false,
        isloading: false,
        error: false,
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
}
componentDidMount() {
  HttpService.logout();
  utilityService.setloginStats(false);
}
ShowLoader()
{
 this.setState({isloading:true});
}
hideLoader()
{
 this.setState({isloading:false});
}
handleChange(e) {
  const { name, value } = e.target;
  this.setState({ [name]: value });
  const obj = this.state.UserModel;
  obj[name] = value;
  this.setState({ UserModel: obj });
}

handleSubmit(e) {
    this.setState({ error: false });
  e.preventDefault();
  this.setState({ submitted: true });
      if (!(this.state.UserModel.Username && this.state.UserModel.Password)) {
        return;
    }
    this.ShowLoader();
    HttpService.post("Auth/Validate",this.state.UserModel).then(
      (result) => {
          this.hideLoader();
         
          sessionStorage.setItem("token",result.data.accessToken);
          utilityService.setloginStats(true);
        //   const { from } = this.props.location.state || { from: { pathname: "/Student" } };
        //   this.props.history.push(from);
          window.location.href=window.location.origin +"/"+"Student";
          this.setState((prevState) => {
              return {
               
               
              }

          },()=>{
        
          })
      },
      (error) => {
        this.setState({ error: true });
        this.hideLoader();
         console.log(error);
      }
  )
 
}

  render() {
    return (
       
            <div>
                 {
         this.state.isloading &&   <Loading></Loading>
        }
        
        <div className="col-md-6 col-md-offset-3">
           
           <h2>Login</h2>
           
           <Form onSubmit={this.handleSubmit}>
                   <Form.Group controlId="formBasicEmail"
                    className={'form-group' + (this.state.submitted && !this.state.UserModel.Username ? ' has-error' : '')}>
                       <Form.Label>UserName</Form.Label>
                       <Form.Control type="text" placeholder="Enter UserId" name="Username" 
                           value={this.state.UserModel.Username} 
                           onChange={this.handleChange}
                       />
                       {this.state.submitted && !this.state.UserModel.Username &&
                       <div style={{color: "red"}}>Username is required</div>
                   }
                   </Form.Group>
                   <Form.Group controlId="formBasicPassword" className={'form-group' + (this.state.submitted && !this.state.UserModel.Password ? ' has-error' : '')}>
                       <Form.Label>Password</Form.Label>
                       <Form.Control type="password" placeholder="Enter Password" name="Password" 
                           value={this.state.UserModel.Password} 
                           onChange={this.handleChange}
                       />
                       {this.state.submitted && !this.state.UserModel.Password &&
                       <div style={{color: "red"}}>Password is required</div>
                   }
                   </Form.Group>

                  <button className="btn btn-primary" disabled={this.state.isloading}>Login</button>
                  {this.state.error &&
                   <span className={'alert alert-danger'}>Incorrect Credentials.</span>
               }
           </Form>
       </div>
            </div>
        );
  }
}
export default Login