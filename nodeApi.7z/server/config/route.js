

var userController = require('../controller/userController');

module.exports = function (app, dir) {

   
    app.get('/', userController.testServer);
    app.get('/users', userController.getAllUsers);
    

  

}
