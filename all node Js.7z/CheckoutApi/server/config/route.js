


var checkoutController = require('../controller/CheckoutController');


module.exports = function (app, dir) {
    
   let routePath='/checkoutApi'
   app.get(routePath, checkoutController.test);
    app.get(routePath+'/payBillAndCheckout', checkoutController.payBillAndCheckout);
    
}
