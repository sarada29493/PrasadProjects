import React from 'react'
import { Button ,Alert,Navbar,Nav,Form,FormControl,Modal} from 'react-bootstrap';
import {HttpService} from '../Services/Http.Service';
class StudentDetails extends React.Component {
   
    constructor(props,context) {
        super(props,context);
    this.handleClose = this.handleClose.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.SaveToDb = this.SaveToDb.bind(this);
    this.state = {
      show: true,
      submitted:false,
      studentObj:  { id: 0, name: "",age:0 }
    };
    
    }
    SaveToDb()
   {
    this.setState({ submitted: false });
    HttpService.post("Student/updateStudent",this.state.studentObj)
     .then(
        (result) => {
           // this.hideLoader();
            this.setState((prevState) => {
                return {
                 // Set State
                 
                }

            },()=>{
                this.props.loadData();
                this.handleClose();
             //call any function after set is state.
            })
        },
        (error) => {
          
           console.log(error);
        }
    );
   }
    handleSubmit(e) {
      e.preventDefault();
      this.setState({ submitted: true });
          if (!(this.state.studentObj.name && this.state.studentObj.age>0)) {
            return;
        }
      this.SaveToDb();
    }
      handleClose() {
        this.props.reset();
      }
      AddOrUpdateStudent(data) {
        this.setState({  studentObj:data });
      }
      handleChange(e) {
        const { name, value } = e.target;
        this.setState({ [name]: value });
        const obj = this.state.studentObj;
        obj[name] = value;
        this.setState({ studentObj: obj });
      }
      
     
      render() {
        return (
           <div>
              <Modal show={this.props.isToShow} onHide={this.handleClose} >
          <Modal.Header closeButton>
            <Modal.Title>Modal heading</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <Form >
                   <Form.Group controlId="formBasicName"
                    className={'form-group' + (this.state.submitted && !this.state.studentObj.name ? ' has-error' : '')}>
                       <Form.Label>Name</Form.Label>
                       <Form.Control type="text" placeholder="Enter UserName" name="name" 
                           value={this.state.studentObj.name} 
                           onChange={this.handleChange}
                       />
                       {this.state.submitted && !this.state.studentObj.name &&
                       <div style={{color: "red"}}>Name is required</div>
                   }
                   </Form.Group>
                   <Form.Group controlId="formBasicPassword" className={'form-group' + (this.state.submitted && !this.state.studentObj.age>0 ? ' has-error' : '')}>
                       <Form.Label>Age</Form.Label>
                       <Form.Control type="number" placeholder="Enter Password" name="age" 
                           value={this.state.studentObj.age} 
                           onChange={this.handleChange}
                       />
                       {this.state.submitted && !this.state.studentObj.age>0 &&
                       <div style={{color: "red"}}>Age is required</div>
                   }
                   </Form.Group>
           </Form>
              </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={this.handleClose}>
              Close
            </Button>
            <Button variant="primary" type="submit" onClick={this.handleSubmit}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>  
           </div>
        );
      }
}

export default StudentDetails