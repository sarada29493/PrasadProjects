import React, { Component } from 'react';
import { Button } from "react-bootstrap";
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import AddStudentModalcomponent from '../Student/AddStudentModal'

class StudentListcomponent extends Component {
    state = {
        currentObj: { id: null, name: null, age: null},
        show: false,
        studentList: [{ id: null, name: null, age: null}]
    };
    constructor(props, context) {
        super(props, context);
        this.getStudentList();
     }
    getStudentList = (index) => {
        fetch("http://localhost:51900/api/Student/GetAllStudents")
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState((prevState) => {
                        return {
                            studentList: result,
                            //show: true
                        }
                    })
                },
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            )
    };
    Edit=(cell, row, rowIndex)=> {
        row.age = 67;
        this.child.AddOrUpdateStudent(row);
        this.setState((prevState) => {
            return {
                currentObj:row,
                show:true
            }
        }) 
    }
   updateStudenrDetails  = (data) => {
    this.setState((prevState) => {
        return {
           
            show: false
        }
    })
    this.postData('http://localhost:51900/api/Student/UpdateStudent', data);
};
    reset=()=>{
        this.setState((prevState) => {
          return {
             show:false
          }
      })
      }
    cellButton(cell, row, enumObject, rowIndex) {
        return (
            <Button bsStyle="primary" bsSize="xsmall"
                onClick={() => this.Edit(cell, row, rowIndex)}> Edit </Button>
        )
    }
    postData(url, data) {
        // Default options are marked with *
        return fetch(url, {
            body: JSON.stringify(data), // must match 'Content-Type' header
            cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
            credentials: 'same-origin', // include, same-origin, *omit
            headers: {
                'content-type': 'application/json'
            },
            method: 'POST', // *GET, POST, PUT, DELETE, etc.
            mode: 'cors', // no-cors, cors, *same-origin
            redirect: 'follow', // manual, *follow, error
            referrer: 'no-referrer', // *client, no-referrer
        })
            .then(response => response.json()) // parses response to JSON
    }
    handleClick = (index) => {
        this.setState((prevState) => {
            return {
                currentObj: this.props.cards[index],
                show: true
            }
        })
        this.props.setCurrentCardObj(this.props.cards[index]);
    };
    AddNewStudent = (index) => {
        this.child.AddOrUpdateStudent(this.state.currentObj);
        this.setState((prevState) => {
            return {
                show: true
               
            }
        },function () {
            console.log(this.state.show);
        })
        
    };
    render() {
        return (
            <div>
                <Button bsStyle="primary" bsSize="xsmall"
                     onClick={this.AddNewStudent}> Add New Student </Button>
                {
                     
                    <AddStudentModalcomponent ref={instance => { this.child = instance; }}

                     isToShow={this.state.show} reset={this.reset} updateStudenrDetails={this.updateStudenrDetails}
                      ></AddStudentModalcomponent>}

                <BootstrapTable data={this.state.studentList}>
                    <TableHeaderColumn dataField='id' isKey>ID</TableHeaderColumn>
                    <TableHeaderColumn dataField='name'>Name</TableHeaderColumn>
                    <TableHeaderColumn dataField='age'>Age</TableHeaderColumn>
                    <TableHeaderColumn dataField='button' dataFormat={this.cellButton.bind(this)} >Action </TableHeaderColumn>
                </BootstrapTable>
            </div>

        );
    }
}
export default StudentListcomponent;
