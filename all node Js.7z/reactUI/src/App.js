import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Button ,Alert,Navbar,Nav,Form,FormControl} from 'react-bootstrap';
import { Table } from "react-bootstrap";
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import StudentList from './Student/studentList';


function App() {
  return (
    <div>
      <p>React App coming</p>
      <Button variant="primary">Primary</Button>
    <StudentList></StudentList>

    </div>
  );
}

export default App;
