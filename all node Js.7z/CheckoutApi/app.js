var express = require('express');
var cors = require('cors');



var env = process.env.NODE_ENV = process.env.NODE_ENV || 'development';
var app = express();
var directoryName = __dirname;

var config = require('./server/config/config')[env];



config.rootPath = directoryName;

require('./server/config/express')(app, config);
app.set('superSecret', config.secret);
app.use(cors());
require('./server/config/route')(app, directoryName);

var SocketIoConfigOb = require('./server/config/SocketIoConfig');
SocketIoConfigOb.intializeServerWithSocket(app,config);
// const server = require('http').createServer(app);
// const io = require('socket.io')(server);
// io.on('connection',socket=> {
//     console.log('A user connected');
//     setTimeout(function() {
//         socket.send('Sent a message 4seconds after connection!');
//      }, 4000);
//     });

// server.listen(config.port, function() {
//     console.log('listening on localhost: '+ config.port);
//  });

// app.listen(config.port, function () {
//     console.log('Example listening on port ' + config.port);
   
// });

