
let rabitMqObj = require("../config/rabitMqConfig");

exports.updateProductPrice = async function (req, res) {
  var queue = 'PriceChangeQue';
  var msg = {"Updated_Price":344};
  var chn=rabitMqObj.getChannel();
  chn.assertQueue(queue, {
          durable: false
   });
   chn.sendToQueue(queue, Buffer.from( JSON.stringify(msg)));

  res.json({
    msg:"Price Updated."
  });
    
};
exports.getProductDetails = async function (req, res) {
  res.json({
   
    list: [{"Id":1,"Name":"Iphone"},{"Id":2,"Name":"Samsung"}]
   
  });
    
};



exports.test = async function (req, res) {
  res.send("Product Microservice Working Fine.");
};

