﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using coreApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;

namespace coreApi.Controllers
{
    [Route("api/Student")]
    [ApiController]
    [Authorize("Bearer")]
    public class StudentController : ControllerBase
    {
        private readonly pinakiDatabaseContext _context;
        public StudentController(pinakiDatabaseContext context, IConfiguration iconfiguration)
        {
            _context = context;

        }
        [HttpGet]
        [Route("GetAllStudent")]
       public  IActionResult getAllStudent()
        {
            try
            {
                var aefe = _context.Set<StudentDemo>().FromSql("dbo.SelectStudentwithName @Id = {0}, @Name = {1}", 17, "pinaki2");

                var res = _context.Student.ToList();
                return Ok(res);
            }
            catch(Exception e)
            {
                return BadRequest(e);
            }
            
        }
        [HttpPost]
        [Route("updateStudent")]
        public IActionResult updateStudent(Student obj)
        {
            if (obj.Id > 0)
            {
                _context.Student.Update(obj);
            }
            else
            {
                _context.Student.Add(obj);
            }
            _context.SaveChanges();
            
            return Ok();
        }
        [HttpGet]
        [Route("RemoveStudent")]
        public IActionResult RemoveStudent(int id)
        {
            IList<Student> list = _context.Student.Where(x => x.Id == id).ToList();
            _context.RemoveRange(list);
            _context.SaveChanges();
            return Ok();
        }
    }
}