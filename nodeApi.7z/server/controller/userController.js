var userModel = require('../model/user');
var ObjectId = require('mongodb').ObjectID;
var UserModelSchema=userModel.getUserModelSchema();


exports.testServer = function (req, res) {
    res.send("Server Working...");
};
exports.getAllUsers = function (req, res) {
    UserModelSchema.find({}).exec(function (err, collection) {
        res.send(collection);
    })
};