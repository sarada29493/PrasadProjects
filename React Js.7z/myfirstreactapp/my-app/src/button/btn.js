import React, { Component } from 'react';
class Button extends Component {
  handleClick = () => {
    this.props.onClickFunction(this.props.incrememtValue)
  };
  render() {
    return (
      <button onClick={this.handleClick}>
        {this.props.incrememtValue}</button>
    );
  }
}
export default Button;
