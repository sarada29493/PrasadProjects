const Sequelize = require("sequelize");
const path = require('path');

let userCrenSchema = require("../model/UserCren");
var conn;
(async function() {
    if(!conn) {
        try {
            const dbName= __dirname+'/server/db/database.sqlite'; 
            // Initialize the connection on the first run
            conn = 
            new Sequelize({
                dialect: 'sqlite',
                storage:  path.join(__dirname, '..', '/db/database_test.sqlite')
              });
            console.log("Connected to the database.");
            await conn.sync();
           
        } catch (error) {
            console.log("There was a problem with connection.\n" + error);
        }
    }
})();
const PersonCren = conn.define("UserCren", userCrenSchema.UserCrenSchema);
module.exports = {
    connection: conn,
    models: {
        PersonCrenTable: PersonCren
    }
}