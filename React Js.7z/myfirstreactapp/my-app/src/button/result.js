import React from 'react';
const Result = (props) => {
    return (
        <div>result Coming soon...{props.counter}</div>
    )
}
export default Result;