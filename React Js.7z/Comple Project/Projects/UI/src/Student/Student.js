import React from 'react'
import { Table,Button } from 'reactstrap';
import {HttpService} from '../Services/Http.Service';
import Loading from '../Loader/Loading';
import {utilityService} from '../Services/utilities';
import StudentDetails from './StudentDetails'


class Student extends React.Component {
    constructor(props,context)
    {
        super(props,context);
        this.state={
            StudentList :[
              { id: 0, name: "",age:0 },
            ],
            listItems:null,
            isloading:false,
            isToShow:false,
            isLogin:false

           }
           setTimeout(function(){
           //this.getStudentList();
           }.bind(this),
           1000);
           this.getStudentList = this.getStudentList.bind(this);
           this.AddStudentDetails = this.AddStudentDetails.bind(this);
           this.reset = this.reset.bind(this);
           this.checkLogin = this.checkLogin.bind(this);
         
     
    }
    checkLogin() {
      var sef= utilityService.getloginStats();
      this.setState({isLogin:sef});
  }
    
    componentDidMount() {
        this.getStudentList();
        this.checkLogin();
    }
    ShowLoader()
   {
    this.setState({isloading:true});
   }
   hideLoader()
   {
    this.setState({isloading:false});
   }
   reset()
   {
    this.setState({isToShow:false});
   }
   
   AddStudentDetails()
   {
     this.child.AddOrUpdateStudent( { id: 0, name: "",age:0 });
     this.setState({isToShow:true});
   }
   Delete(item)
   {
    this.ShowLoader();
    HttpService.get("Student/RemoveStudent?id="+item.id).then(
      (result) => {
        this.getStudentList();
      }
      
    );
   }
   Edit(item,rowIndex) {
      
    this.child.AddOrUpdateStudent(item);
    this.setState({isToShow:true}); 
    }

        getStudentList()
        {
          this.ShowLoader();
            HttpService.get("Student/GetAllStudent")
          .then(
              (result) => {
                  this.hideLoader();
                  this.setState((prevState) => {
                      return {
                        StudentList: result,
                        name:"wqefr43",
                        listItems:result.map(function(item,i) {
                          return (
                            <tr key={i}>
                            <td>{item.name}</td>
                            <td>{item.age}</td>
                            <td> 
                              <Button color="primary"  onClick = {()=>this.Edit(item,i)}
                                >Edit</Button>
                              <Button className="danger"  onClick = {()=>this.Delete(item)}
                                >Delete</Button>
                                
                            </td>
                            </tr>
                           
                          );
                        },this)
                       
                      }

                  },()=>{
                   var ed=this.state.blogList;
                  })
              },
              (error) => {
                this.hideLoader();
                if(error==401)
                {
                  const { from } = this.props.location.state || { from: { pathname: "/Login" } };
                  this.props.history.push(from);
                }
                 console.log(error);
              }
          )
        }

  render() {
    return <div>
      <Button color="danger" onClick={this.AddStudentDetails}>AddStudent</Button>
        {
         this.state.isloading &&   <Loading></Loading>
        }
        {
          <StudentDetails  ref={instance => { this.child = instance; }} loadData={this.getStudentList}
          isToShow={this.state.isToShow} reset={this.reset}>
          </StudentDetails>
        }
              
            <Table>
            <thead>
              <tr>
            
                <th>Name</th>
                <th>Age</th>
                <th>Action</th>
               
              </tr>
            </thead>
            <tbody>
            {this.state.listItems}
            </tbody>
          </Table>
        
            </div>
  }
}
export default Student