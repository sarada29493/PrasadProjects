import React from 'react'
import { Table,Button } from 'reactstrap';
import {HttpService} from '../services/Http.Service';
import { connect } from 'react-redux';

import { bindActionCreators } from 'redux';

class StudentDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            originAmount: '0.00',
            usersTemp:[]    
            }
    }    componentDidMount() {
     
        this.fetchUsers();
    }  
    fetchUsers(){
       
        HttpService.get("getAllUserCren").then(
            (result) => {
                console.log(result);
                this.props.dispatch({type:'change_getUsers',data:result}) ;
            }
          );  
    }
    render() {
        let listItems = this.props.usersTemp.map((number) =>
        <li key={number.Password}>
              {number.Email}
              </li>
            );
        return (
            <div>
                  <ul>{listItems}</ul>
                <p>
            {this.props.users}
                </p>
                <p>
               <div>{this.props.usersTemp[0].Password}</div>
                <label>{this.props.originalAmount}</label>
                <label>{this.state.originalAmount}</label>
                {/* <div>{this.state.usersTemp[0].Password}</div> */}
                </p> 
            </div>
        )
    }
}
export default connect(function mapping(state,props){
    console.log('state:'+JSON.stringify( state));
    console.log('props:'+JSON.stringify( props));
        return{
            usersTemp:state.users,
            originalAmount:state.originAmount,
           
        }
}
) (StudentDetail);