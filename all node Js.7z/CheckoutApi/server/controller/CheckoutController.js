
 let rabitMqObj = require("../config/rabitMqConfig");

 let SocketIoConfigOb = require('../config/SocketIoConfig');
setTimeout( function() {
 
  var Msg;
  var chn=rabitMqObj.getChannel();
  var queue = 'PriceChangeQue';

  chn.assertQueue(queue, {
      durable: false
    });
    chn.consume(queue, function(msg) {
      Msg= JSON.parse(msg.content) ;
      console.log(" [x] Received %s", Msg.Updated_Price);
      var io=SocketIoConfigOb.getSocketIo();
      io.sockets.emit('broadcast',{ description:  ' Price Updated..'});
    }, {
        noAck: true
      });


}, 1000);


exports.payBillAndCheckout = async function (req, res) {
  
  res.json({
   
    msg:{"orderId":5,"Price":"700"}
   
  });
    
};


exports.test = async function (req, res) {
  res.send("Checkout Microservice Working Fine.");
};

