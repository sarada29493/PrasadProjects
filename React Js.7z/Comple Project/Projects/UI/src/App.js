import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { Button ,Alert,Navbar,Nav,Form,FormControl} from 'react-bootstrap';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom';
import Student from './Student/Student';
import Login from './Login/Login';
import Home from './Home/Home';
import {utilityService} from './Services/utilities';
import {HttpService} from './Services/Http.Service';

class App extends Component {

  constructor(props) {
    super(props);

    this.state = {
      isLoginBtnvisible: true,
      modal: false,
      isLogin:false,
      name:"wef"
      
    };
    setTimeout(function(){
      this.checkLogin();
      }.bind(this),
      700);
   
    this.login2 = this.login2.bind(this);
    this.checkLogin = this.checkLogin.bind(this);
  }
  componentDidMount()
  {
   // this.checkLogin();
  }
  checkLogin() {
    this.setState({isLogin:JSON.parse(utilityService.getloginStats())});
}
  login2() {
    var d=this.state.isLoginBtnvisible;
   
   window.location.href=window.location.origin +"/"+"Login";
 
  }
  render() {
    return (
      <div>
         
    <Router>
        <div>
        <Navbar bg="dark" variant="dark">
        <Navbar.Brand href="/">Navbar</Navbar.Brand>
        <Nav className="mr-auto">
          <Nav.Link href="/">Home</Nav.Link>
          <Nav.Link href="/Student">Student</Nav.Link>
          {/* <Nav.Link href="/Login">Login</Nav.Link> */}
        </Nav>
        <Form inline>
          {/* <FormControl type="text" placeholder="Search" className="mr-sm-2" />
          <Button variant="outline-info">Search</Button> */}
          {
         this.state.isLogin &&   <Button variant="outline-info" onClick={this.login2}>Logout</Button>
        }
        {
         !this.state.isLogin &&    <Button variant="outline-info" onClick={this.login2}>Login</Button>
        }
         
         
        </Form>
        </Navbar>
          
          <Route  exact path="/" component={Home} />
          <Route path="/Student" component={Student}   />
          <Route path="/Login" component={Login} />
        </div>
      </Router>
      </div>
    );
  }
}

export default App;
