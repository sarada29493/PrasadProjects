

import React from 'react';
const Card = (props) => {
    this.obj = props.counter;
    // this.obj.name = 'pinaki';
    // this.obj.age = 25;
    // this.obj.email = 'pinaki.best@gmail.com'
   return (
        <div>
           <div>{this.obj.name}
           </div>
            <div>{this.obj.age}
           </div>
            <div>{this.obj.email}
           </div>
        </div>
   )
}
export default Card;
