var express = require('express');
var cors = require('cors');

var env = process.env.NODE_ENV = process.env.NODE_ENV || 'development';

var app = express();

var port=3031;
var getAllUsers= function (req, res) {
    res.send("Server working");
    }
app.use(cors());
app.get('/',getAllUsers);
app.listen(port, function () { console.log('Example listening on port ' + port);
});
