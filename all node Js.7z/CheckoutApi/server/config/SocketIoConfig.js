var amqp = require('amqplib/callback_api');

var server;
var io;
 exports.intializeServerWithSocket =  function (app,config) {
    try {
        server = require('http').createServer(app);
            io = require('socket.io')(server);
           io.on('connection',socket=> {
               console.log('A user connected');
              
               });

           server.listen(config.port, function() {
               console.log('listening on localhost: '+ config.port);
           }); 
   } catch (error) {
       console.log("There was a problem with connection.\n" + error);
   }
};


exports.getSocketIo =  function () {
    return io;
};
