
var userCrenController = require('../controller/UserCrenController');
module.exports = function (app, dir) {
   let routePath='/loginApi'
   app.get(routePath, userCrenController.test);
    app.get(routePath+'/getAllUserCren', userCrenController.getAllUserCren);
    app.post(routePath+'/auntheticate', userCrenController.auntheticate);
}
