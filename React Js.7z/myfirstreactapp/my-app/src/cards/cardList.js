import React, { Component } from 'react';
import Card from '../cards/cardDetails';
import ToggleDisplay from 'react-toggle-display';
class Cardlistcomponent extends Component {
    state = {
       currentObj: {},
        show: false
    };
    handleClick = (index) => {
        this.setState((prevState) => {
            return {
                currentObj: this.props.cards[index],
                show:true
            }
        })
        this.props.setCurrentCardObj(this.props.cards[index]);
   };
    render() {
        return (
            <div>
                <div>
                    {
                        this.props.cards.map(function (item, i) {
                            return (
                                <div key={i}>
                                    <div>{item.name}
                                    </div>
                                    <div>{item.age}
                                    </div>
                                    <div>{item.email}
                                    </div>
                                    <div><button onClick={() => this.handleClick(i)}
                                    >Show Details</button>
                                    </div>
                                </div>
                            )
                        }.bind(this))
                    }
                </div>
                <div>
                    <ToggleDisplay if={this.state.show} tag="section">
                    <Card counter={this.state.currentObj}></Card>
                    </ToggleDisplay>
               </div>
           </div>);
    }
}
export default Cardlistcomponent;
