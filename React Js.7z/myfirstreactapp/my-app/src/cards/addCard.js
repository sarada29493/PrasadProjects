
import React, { Component } from 'react';
import ToggleDisplay from 'react-toggle-display';
import {HelpBlock, FormGroup, FormControl, ControlLabel, Modal, Button, Form, Col, Checkbox} from "react-bootstrap";
import { Row } from 'react-bootstrap';

class AddCardcomponent extends Component {
    constructor(props, context) {
        super(props, context);
        this.handleShow = this.handleShow.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleChange = this.handleChange.bind(this);
   }
   state = {
       show: this.props.isToShow,
        newCard:    this.props.existingCardDetails,
   };
   AddCard = (event) => {
        event.preventDefault();
       this.props.onAddtoList (this.state.newCard);
        console.log('submitted...');
        this.handleClose();
        // this.setState((prevState) => {
        //     return {
       //         show: true
        //     }
        // })
   };
    handleClose() {
        this.setState({ show: false });
        this.props.onClickClose();
    }
   handleShow() {
        this.setState({ show: true });
    }
    handleChange= (propertyName, event)=> {
        const obj = this.state.newCard;
        obj[propertyName] = event.target.value;
        this.setState({ newCard: obj });
      }
    setName = (event) => {
        this.setState(
            { name: event.target.value }
        )
    }
    render() {
        return (
           <div>
                <p>Click to get the full Modal experience!</p>
               <Button bsStyle="primary" bsSize="large" onClick={this.handleShow}>
                    Launch demo modal
            </Button>
               <Modal show={this.state.show} onHide={this.handleClose}>
                    <Modal.Header closeButton>
                        <Modal.Title>Modal heading</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <Form horizontal onSubmit={this.AddCard.bind(this)}>
                            <FormGroup controlId="formHorizontalName">
                                <Col componentClass={ControlLabel} sm={1}>
                                    name
                                </Col>
                                <Col sm={10}>
                                    <FormControl type="text" 
                                    onChange={this.handleChange.bind(this, 'name')} 
                                    value={this.state.newCard.name}
                                     placeholder="name" />
                                </Col>
                            </FormGroup>
                           <FormGroup controlId="formHorizontalAge">
                                <Col componentClass={ControlLabel} sm={2}>
                                    Age
                                </Col>
                                <Col sm={10}>
                                    <FormControl type="number" 
                                    onChange={this.handleChange.bind(this, 'age')} 
                                    value={this.state.newCard.age}
                                     placeholder="name" />
                                </Col>
                            </FormGroup>
                          <FormGroup controlId="formHorizontalEmail">
                                <Col componentClass={ControlLabel} sm={2}>
                                    Email
                                </Col>
                                <Col sm={10}>
                                    <FormControl type="text" 
                                    onChange={this.handleChange.bind(this, 'email')} 
                                    value={this.state.newCard.email}
                                     placeholder="email" />
                                </Col>
                            </FormGroup>
                           <FormGroup>
                                <Col smOffset={2} sm={10}>
                                    <Button type="submit">Add</Button>
                                </Col>
                            </FormGroup>
                        </Form>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={this.handleClose}>Close</Button>
                    </Modal.Footer>
                </Modal>
            </div>
       );
    }
}
export default AddCardcomponent;